create definer = admin@`%` view costs_for_sequence as
select `s`.`sequence_id`           AS `sequence_id`,
       `s`.`assembly_operation_id` AS `assembly_operation_id`,
       `s`.`quality_test_id`       AS `quality_test_id`,
       `ao`.`ao_eng_cost`          AS `cost1`,
       `ao`.`sum_skills_eng_cost`  AS `cost2`
from (`micro_macro`.`sequences_operations` `s`
         left join `micro_macro`.`assembly_operations` `ao`
                   on ((`ao`.`assembly_operation_id` = `s`.`assembly_operation_id`)))
where (`s`.`op_type` = 'ao')
union
select `s`.`sequence_id`           AS `sequence_id`,
       `s`.`assembly_operation_id` AS `assembly_operation_id`,
       `s`.`quality_test_id`       AS `quality_test_id`,
       `qt`.`qt_eng_cost`          AS `cost1`,
       `qt`.`skills_eng_cost`      AS `cost2`
from (`micro_macro`.`sequences_operations` `s`
         left join `micro_macro`.`quality_tests` `qt` on ((`qt`.`quality_test_id` = `s`.`quality_test_id`)))
where (`s`.`op_type` = 'qt');

