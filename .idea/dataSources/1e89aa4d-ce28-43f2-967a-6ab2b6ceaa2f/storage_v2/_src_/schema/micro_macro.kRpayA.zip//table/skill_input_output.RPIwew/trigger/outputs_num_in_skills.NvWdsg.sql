create definer = admin@`%` trigger outputs_num_in_skills
    after insert
    on skill_input_output
    for each row
    UPDATE skills
    SET inputs_num = (select count(*)
						from skill_input_output
						where skill_input_output.skill_id = skills.skill_id and input_output = 'output'
										);

