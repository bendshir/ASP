create definer = admin@`%` trigger equipments_num_in_ao
    after insert
    on ao_actors
    for each row
    UPDATE assembly_operations
    SET equipments_num = (select count(*)
						from ao_actors
						where ao_actors.assembly_operation_id = assembly_operations.assembly_operation_id
										);

