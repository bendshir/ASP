create definer = admin@`%` trigger no_AO_QT_in_sequences
    after insert
    on sequences_operations
    for each row
    UPDATE sequences
    SET no_AO_QT = (select count(*)
						from sequences_operations
						where sequences_operations.sequence_id = sequences.sequence_id 
										);

