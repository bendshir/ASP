create definer = admin@`%` trigger seq_cost_after_update_qt
    after update
    on quality_tests
    for each row
    UPDATE sequences
    SET sum_ao_qt_eng_cost = (select sum(cost1)+sum(cost2)
												from costs_for_sequence as v1
												where v1.sequence_id = sequences.sequence_id
                                                    );

