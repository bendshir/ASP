create definer = admin@`%` trigger materials_num_in_ao
    after insert
    on ao_materials
    for each row
    UPDATE assembly_operations
    SET materials_num = (select count(*)
						from ao_materials
						where ao_materials.assembly_operation_id = assembly_operations.assembly_operation_id
										);

